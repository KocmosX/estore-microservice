package com.example.demo.service;

import com.example.demo.model.PaymentType;
import com.example.demo.repository.PaymentTypeRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PaymentTypeService {

    private final PaymentTypeRepository paymentTypeRepository;

    public PaymentTypeService(PaymentTypeRepository paymentTypeRepository) {
        this.paymentTypeRepository = paymentTypeRepository;
    }

    public List<PaymentType> findAll() {
        return paymentTypeRepository.findAll();
    }

    public PaymentType findById(Long id) {
        return paymentTypeRepository.findById(id).orElse(null);
    }

    public PaymentType save(PaymentType paymentType) {
        return paymentTypeRepository.save(paymentType);
    }

    public void deleteById(Long id) {
        paymentTypeRepository.deleteById(id);
    }
}
