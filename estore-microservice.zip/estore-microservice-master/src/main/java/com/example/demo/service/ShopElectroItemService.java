package com.example.demo.service;

import com.example.demo.model.ShopElectroItem;
import com.example.demo.repository.ShopElectroItemRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ShopElectroItemService {

    private final ShopElectroItemRepository shopElectroItemRepository;

    public ShopElectroItemService(ShopElectroItemRepository shopElectroItemRepository) {
        this.shopElectroItemRepository = shopElectroItemRepository;
    }

    public List<ShopElectroItem> findAll() {
        return shopElectroItemRepository.findAll();
    }

    public ShopElectroItem findById(ShopElectroItem.Id id) {
        return shopElectroItemRepository.findById(id).orElse(null);
    }

    public ShopElectroItem save(ShopElectroItem shopElectroItem) {
        return shopElectroItemRepository.save(shopElectroItem);
    }

    public void deleteById(ShopElectroItem.Id id) {
        shopElectroItemRepository.deleteById(id);
    }
}
