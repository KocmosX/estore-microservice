package com.example.demo.controller;

import com.example.demo.model.ElectroItemType;
import com.example.demo.service.ElectroItemTypeService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/electro-item-types")
public class ElectroItemTypeController {

    private final ElectroItemTypeService electroItemTypeService;

    public ElectroItemTypeController(ElectroItemTypeService electroItemTypeService) {
        this.electroItemTypeService = electroItemTypeService;
    }

    @GetMapping
    public ResponseEntity<List<ElectroItemType>> findAll() {
        return ResponseEntity.ok(electroItemTypeService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ElectroItemType> findById(@PathVariable Long id) {
        ElectroItemType electroItemType = electroItemTypeService.findById(id);
        if (electroItemType == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(electroItemType);
    }

    @PostMapping
    public ResponseEntity<ElectroItemType> save(@RequestBody ElectroItemType electroItemType) {
        return ResponseEntity.ok(electroItemTypeService.save(electroItemType));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ElectroItemType> update(@PathVariable Long id, @RequestBody ElectroItemType electroItemType) {
        ElectroItemType existingElectroItemType = electroItemTypeService.findById(id);
        if (existingElectroItemType == null) {
            return ResponseEntity.notFound().build();
        }
        electroItemType.setId(id);
        return ResponseEntity.ok(electroItemTypeService.save(electroItemType));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteById(@PathVariable Long id) {
        ElectroItemType electroItemType = electroItemTypeService.findById(id);
        if (electroItemType == null) {
            return ResponseEntity.notFound().build();
        }
        electroItemTypeService.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}