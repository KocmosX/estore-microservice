package com.example.demo.controller;

import com.example.demo.model.Shop;
import com.example.demo.service.ShopService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/shops")
public class ShopController {

    private final ShopService shopService;

    public ShopController(ShopService shopService) {
        this.shopService = shopService;
    }

    @GetMapping
    public ResponseEntity<List<Shop>> findAll() {
        return ResponseEntity.ok(shopService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Shop> findById(@PathVariable Long id) {
        Shop shop = shopService.findById(id);
        if (shop == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(shop);
    }

    @PostMapping
    public ResponseEntity<Shop> save(@RequestBody Shop shop) {
        return ResponseEntity.ok(shopService.save(shop));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Shop> update(@PathVariable Long id, @RequestBody Shop shop) {
        Shop existingShop = shopService.findById(id);
        if (existingShop == null) {
            return ResponseEntity.notFound().build();
        }
        shop.setId(id);
        return ResponseEntity.ok(shopService.save(shop));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteById(@PathVariable Long id) {
        Shop shop = shopService.findById(id);
        if (shop == null) {
            return ResponseEntity.notFound().build();
        }
        shopService.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}