package com.example.demo.model;

import ru.isands.test.estore.dao.entity.Purchase;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "electro_items")
public class ElectroItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @ManyToOne
    @JoinColumn(name = "etype_id", nullable = false)
    private ElectroItemType electroItemType;

    @Column(nullable = false)
    private Integer price;

    @Column(nullable = false)
    private Integer count;

    @Column(nullable = false)
    private Boolean archive;

    @Column
    private String description;

    @OneToMany(mappedBy = "electroItem")
    private Set<ShopElectroItem> shopElectroItems = new HashSet<>();

    @OneToMany(mappedBy = "electroItem")
    private Set<Purchase> purchases = new HashSet<>();

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public ElectroItemType getElectroItemType() {
        return electroItemType;
    }

    public Integer getPrice() {
        return price;
    }

    public Integer getCount() {
        return count;
    }

    public Boolean getArchive() {
        return archive;
    }

    public String getDescription() {
        return description;
    }

    // Setters
    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setElectroItemType(ElectroItemType electroItemType) {
        this.electroItemType = electroItemType;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public void setArchive(Boolean archive) {
        this.archive = archive;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
