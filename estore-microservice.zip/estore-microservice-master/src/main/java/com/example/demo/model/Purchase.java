package com.example.demo.model;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "purchases")
public class Purchase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "electro_id", nullable = false)
    private ElectroItem electroItem;

    @ManyToOne
    @JoinColumn(name = "employee_id", nullable = false)
    private Employee employee;

    @Column(nullable = false)
    private LocalDateTime purchaseDate;

    @ManyToOne
    @JoinColumn(name = "type_id", nullable = false)
    private PaymentType paymentType;

    @ManyToOne
    @JoinColumn(name = "shop_id", nullable = false)
    private Shop shop;

    // Getters
    public Long getId() {
        return id;
    }

    public ElectroItem getElectroItem() {
        return electroItem;
    }

    public Employee getEmployee() {
        return employee;
    }

    public LocalDateTime getPurchaseDate() {
        return purchaseDate;
    }

    public PaymentType getPaymentType() {
        return paymentType;
    }

    public Shop getShop() {
        return shop;
    }

    // Setters
    public void setId(Long id) {
        this.id = id;
    }

    public void setElectroItem(ElectroItem electroItem) {
        this.electroItem = electroItem;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public void setPurchaseDate(LocalDateTime purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    public void setPaymentType(PaymentType paymentType) {
        this.paymentType = paymentType;
    }

    public void setShop(Shop shop) {
        this.shop = shop;
    }

}
