package com.example.demo.controller;

import com.example.demo.model.PaymentType;
import com.example.demo.service.PaymentTypeService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/payment-types")
public class PaymentTypeController {

    private final PaymentTypeService paymentTypeService;

    public PaymentTypeController(PaymentTypeService paymentTypeService) {
        this.paymentTypeService = paymentTypeService;
    }

    @GetMapping
    public ResponseEntity<List<PaymentType>> findAll() {
        return ResponseEntity.ok(paymentTypeService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<PaymentType> findById(@PathVariable Long id) {
        PaymentType paymentType = paymentTypeService.findById(id);
        if (paymentType == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(paymentType);
    }

    @PostMapping
    public ResponseEntity<PaymentType> save(@RequestBody PaymentType paymentType) {
        return ResponseEntity.ok(paymentTypeService.save(paymentType));
    }

    @PutMapping("/{id}")
    public ResponseEntity<PaymentType> update(@PathVariable Long id, @RequestBody PaymentType paymentType) {
        PaymentType existingPaymentType = paymentTypeService.findById(id);
        if (existingPaymentType == null) {
            return ResponseEntity.notFound().build();
        }
        paymentType.setId(id);
        return ResponseEntity.ok(paymentTypeService.save(paymentType));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteById(@PathVariable Long id) {
        PaymentType paymentType = paymentTypeService.findById(id);
        if (paymentType == null) {
            return ResponseEntity.notFound().build();
        }
        paymentTypeService.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}