package com.example.demo.controller;

import com.example.demo.model.EmployeeType;
import com.example.demo.service.EmployeeTypeService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/employee-types")
public class EmployeeTypeController {

    private final EmployeeTypeService employeeTypeService;

    public EmployeeTypeController(EmployeeTypeService employeeTypeService) {
        this.employeeTypeService = employeeTypeService;
    }

    @GetMapping
    public ResponseEntity<List<EmployeeType>> findAll() {
        return ResponseEntity.ok(employeeTypeService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<EmployeeType> findById(@PathVariable Long id) {
        EmployeeType employeeType = employeeTypeService.findById(id);
        if (employeeType == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(employeeType);
    }

    @PostMapping
    public ResponseEntity<EmployeeType> save(@RequestBody EmployeeType employeeType) {
        return ResponseEntity.ok(employeeTypeService.save(employeeType));
    }

    @PutMapping("/{id}")
    public ResponseEntity<EmployeeType> update(@PathVariable Long id, @RequestBody EmployeeType employeeType) {
        EmployeeType existingEmployeeType = employeeTypeService.findById(id);
        if (existingEmployeeType == null) {
            return ResponseEntity.notFound().build();
        }
        employeeType.setId(id);
        return ResponseEntity.ok(employeeTypeService.save(employeeType));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteById(@PathVariable Long id) {
        EmployeeType employeeType = employeeTypeService.findById(id);
        if (employeeType == null) {
            return ResponseEntity.notFound().build();
        }
        employeeTypeService.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
