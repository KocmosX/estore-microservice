package com.example.demo.service;

import com.example.demo.model.ElectroItem;
import com.example.demo.repository.ElectroItemRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ElectroItemService {

    private final ElectroItemRepository electroItemRepository;

    public ElectroItemService(ElectroItemRepository electroItemRepository) {
        this.electroItemRepository = electroItemRepository;
    }

    public List<ElectroItem> findAll() {
        return electroItemRepository.findAll();
    }

    public ElectroItem findById(Long id) {
        return electroItemRepository.findById(id).orElse(null);
    }

    public ElectroItem save(ElectroItem electroItem) {
        return electroItemRepository.save(electroItem);
    }

    public void deleteById(Long id) {
        electroItemRepository.deleteById(id);
    }
}
