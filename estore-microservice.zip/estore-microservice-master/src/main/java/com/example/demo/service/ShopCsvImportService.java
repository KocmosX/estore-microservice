package com.example.demo.service;

import com.example.demo.model.Shop;
import com.example.demo.repository.ShopRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

@Service
public class ShopCsvImportService {

    private final ShopRepository shopRepository;

    public ShopCsvImportService(ShopRepository shopRepository) {
        this.shopRepository = shopRepository;
    }

    public void importShops(MultipartFile file) throws IOException {
        try (InputStream inputStream = file.getInputStream();
             InputStreamReader reader = new InputStreamReader(inputStream);
             BufferedReader bufferedReader = new BufferedReader(reader)) {

            List<Shop> shops = new ArrayList<>();

            // Пропускаем первую строку (заголовки)
            bufferedReader.readLine();

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                String[] values = line.split(",");

                Shop shop = new Shop();
                shop.setName(values[0]);
                shop.setAddress(values[1]);

                shops.add(shop);
            }

            shopRepository.saveAll(shops);
        }
    }
}
