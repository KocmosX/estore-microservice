package com.example.demo.controller;

import com.example.demo.model.ElectroItem;
import com.example.demo.service.ElectroItemService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/electro-items")
public class ElectroItemController {

    private final ElectroItemService electroItemService;

    public ElectroItemController(ElectroItemService electroItemService) {
        this.electroItemService = electroItemService;
    }

    @GetMapping
    public ResponseEntity<List<ElectroItem>> findAll() {
        return ResponseEntity.ok(electroItemService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ElectroItem> findById(@PathVariable Long id) {
        ElectroItem electroItem = electroItemService.findById(id);
        if (electroItem == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(electroItem);
    }

    @PostMapping
    public ResponseEntity<ElectroItem> save(@RequestBody ElectroItem electroItem) {
        return ResponseEntity.ok(electroItemService.save(electroItem));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ElectroItem> update(@PathVariable Long id, @RequestBody ElectroItem electroItem) {
        ElectroItem existingElectroItem = electroItemService.findById(id);
        if (existingElectroItem == null) {
            return ResponseEntity.notFound().build();
        }
        electroItem.setId(id);
        return ResponseEntity.ok(electroItemService.save(electroItem));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteById(@PathVariable Long id) {
        ElectroItem electroItem = electroItemService.findById(id);
        if (electroItem == null) {
            return ResponseEntity.notFound().build();
        }
        electroItemService.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}