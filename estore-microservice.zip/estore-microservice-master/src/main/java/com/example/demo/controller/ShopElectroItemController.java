package com.example.demo.controller;

import com.example.demo.model.ShopElectroItem;
import com.example.demo.service.ShopElectroItemService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/shop-electro-items")
public class ShopElectroItemController {

    private final ShopElectroItemService shopElectroItemService;

    public ShopElectroItemController(ShopElectroItemService shopElectroItemService) {
        this.shopElectroItemService = shopElectroItemService;
    }

    @GetMapping
    public ResponseEntity<List<ShopElectroItem>> findAll() {
        return ResponseEntity.ok(shopElectroItemService.findAll());
    }

    @GetMapping("/{shopId}/{electroItemId}")
    public ResponseEntity<ShopElectroItem> findById(@PathVariable Long shopId, @PathVariable Long electroItemId) {
        ShopElectroItem shopElectroItem = shopElectroItemService.findById(new ShopElectroItem.Id(shopId, electroItemId));
        if (shopElectroItem == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(shopElectroItem);
    }

    @PostMapping
    public ResponseEntity<ShopElectroItem> save(@RequestBody ShopElectroItem shopElectroItem) {
        return ResponseEntity.ok(shopElectroItemService.save(shopElectroItem));
    }

    @PutMapping("/{shopId}/{electroItemId}")
    public ResponseEntity<ShopElectroItem> update(@PathVariable Long shopId, @PathVariable Long electroItemId, @RequestBody ShopElectroItem shopElectroItem) {
        ShopElectroItem existingShopElectroItem = shopElectroItemService.findById(new ShopElectroItem.Id(shopId, electroItemId));
        if (existingShopElectroItem == null) {
            return ResponseEntity.notFound().build();
        }
        shopElectroItem.setId(new ShopElectroItem.Id(shopId, electroItemId));
        return ResponseEntity.ok(shopElectroItemService.save(shopElectroItem));
    }

    @DeleteMapping("/{shopId}/{electroItemId}")
    public ResponseEntity<Void> deleteById(@PathVariable Long shopId, @PathVariable Long electroItemId) {
        ShopElectroItem shopElectroItem = shopElectroItemService.findById(new ShopElectroItem.Id(shopId, electroItemId));
        if (shopElectroItem == null) {
            return ResponseEntity.notFound().build();
        }
        shopElectroItemService.deleteById(new ShopElectroItem.Id(shopId, electroItemId));
        return ResponseEntity.noContent().build();
    }
}