package com.example.demo.service;

import com.example.demo.model.EmployeeType;
import com.example.demo.repository.EmployeeTypeRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeTypeService {

    private final EmployeeTypeRepository employeeTypeRepository;

    public EmployeeTypeService(EmployeeTypeRepository employeeTypeRepository) {
        this.employeeTypeRepository = employeeTypeRepository;
    }

    public List<EmployeeType> findAll() {
        return employeeTypeRepository.findAll();
    }

    public EmployeeType findById(Long id) {
        return employeeTypeRepository.findById(id).orElse(null);
    }

    public EmployeeType save(EmployeeType employeeType) {
        return employeeTypeRepository.save(employeeType);
    }

    public void deleteById(Long id) {
        employeeTypeRepository.deleteById(id);
    }
}
