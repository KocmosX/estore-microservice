package com.example.demo.service;

import com.example.demo.model.ElectroItemType;
import com.example.demo.repository.ElectroItemTypeRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ElectroItemTypeService {

    private final ElectroItemTypeRepository electroItemTypeRepository;

    public ElectroItemTypeService(ElectroItemTypeRepository electroItemTypeRepository) {
        this.electroItemTypeRepository = electroItemTypeRepository;
    }

    public List<ElectroItemType> findAll() {
        return electroItemTypeRepository.findAll();
    }

    public ElectroItemType findById(Long id) {
        return electroItemTypeRepository.findById(id).orElse(null);
    }

    public ElectroItemType save(ElectroItemType electroItemType) {
        return electroItemTypeRepository.save(electroItemType);
    }

    public void deleteById(Long id) {
        electroItemTypeRepository.deleteById(id);
    }
}
