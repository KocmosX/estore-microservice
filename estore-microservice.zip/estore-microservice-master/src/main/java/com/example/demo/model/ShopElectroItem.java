package com.example.demo.model;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "shop_electro_items")
public class ShopElectroItem {

    @Embeddable
    public static class Id implements Serializable {

        private Long shopId;

        private Long electroItemId;

        public Id() {}

        public Id(Long shopId, Long electroItemId) {
            this.shopId = shopId;
            this.electroItemId = electroItemId;
        }

        // Getters and setters
        public Long getShopId() {
            return shopId;
        }

        public void setShopId(Long shopId) {
            this.shopId = shopId;
        }

        public Long getElectroItemId() {
            return electroItemId;
        }

        public void setElectroItemId(Long electroItemId) {
            this.electroItemId = electroItemId;
        }

        // equals and hashCode
        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Id)) return false;

            Id id = (Id) o;

            if (!getShopId().equals(id.getShopId())) return false;
            return getElectroItemId().equals(id.getElectroItemId());
        }

        @Override
        public int hashCode() {
            int result = getShopId().hashCode();
            result = 31 * result + getElectroItemId().hashCode();
            return result;
        }
    }

    @EmbeddedId
    private Id id;

    @ManyToOne
    @MapsId("shopId")
    private Shop shop;

    @ManyToOne
    @MapsId("electroItemId")
    private ElectroItem electroItem;

    @Column(nullable = false)
    private Integer count;

    public Shop getShop() {
        return shop;
    }

    public ElectroItem getElectroItem() {
        return electroItem;
    }

    public Integer getCount() {
        return count;
    }

    // Setters
    public void setShop(Shop shop) {
        this.shop = shop;
        this.id.setShopId(shop.getId());
    }

    public void setElectroItem(ElectroItem electroItem) {
        this.electroItem = electroItem;
        this.id.setElectroItemId(electroItem.getId());
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public void setId(Id id) {
        this.id = id;
    }
}
