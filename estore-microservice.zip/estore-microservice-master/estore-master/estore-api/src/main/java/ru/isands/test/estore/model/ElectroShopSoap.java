/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package ru.isands.test.estore.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

import ru.isands.test.estore.service.persistence.ElectroShopPK;

/**
 * This class is used by SOAP remote services.
 *
 * @author Brian Wing Shun Chan
 * @deprecated As of Athanasius (7.3.x), with no direct replacement
 * @generated
 */
@Deprecated
public class ElectroShopSoap implements Serializable {

	public static ElectroShopSoap toSoapModel(ElectroShop model) {
		ElectroShopSoap soapModel = new ElectroShopSoap();

		soapModel.setShopId(model.getShopId());
		soapModel.setElectroItemId(model.getElectroItemId());
		soapModel.setCount(model.getCount());

		return soapModel;
	}

	public static ElectroShopSoap[] toSoapModels(ElectroShop[] models) {
		ElectroShopSoap[] soapModels = new ElectroShopSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static ElectroShopSoap[][] toSoapModels(ElectroShop[][] models) {
		ElectroShopSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new ElectroShopSoap[models.length][models[0].length];
		}
		else {
			soapModels = new ElectroShopSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static ElectroShopSoap[] toSoapModels(List<ElectroShop> models) {
		List<ElectroShopSoap> soapModels = new ArrayList<ElectroShopSoap>(
			models.size());

		for (ElectroShop model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new ElectroShopSoap[soapModels.size()]);
	}

	public ElectroShopSoap() {
	}

	public ElectroShopPK getPrimaryKey() {
		return new ElectroShopPK(_shopId, _electroItemId);
	}

	public void setPrimaryKey(ElectroShopPK pk) {
		setShopId(pk.shopId);
		setElectroItemId(pk.electroItemId);
	}

	public long getShopId() {
		return _shopId;
	}

	public void setShopId(long shopId) {
		_shopId = shopId;
	}

	public long getElectroItemId() {
		return _electroItemId;
	}

	public void setElectroItemId(long electroItemId) {
		_electroItemId = electroItemId;
	}

	public int getCount() {
		return _count;
	}

	public void setCount(int count) {
		_count = count;
	}

	private long _shopId;
	private long _electroItemId;
	private int _count;

}