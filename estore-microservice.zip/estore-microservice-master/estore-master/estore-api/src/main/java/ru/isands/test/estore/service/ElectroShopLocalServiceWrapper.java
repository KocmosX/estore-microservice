/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package ru.isands.test.estore.service;

import com.liferay.portal.kernel.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link ElectroShopLocalService}.
 *
 * @author Brian Wing Shun Chan
 * @see ElectroShopLocalService
 * @generated
 */
public class ElectroShopLocalServiceWrapper
	implements ElectroShopLocalService,
			   ServiceWrapper<ElectroShopLocalService> {

	public ElectroShopLocalServiceWrapper(
		ElectroShopLocalService electroShopLocalService) {

		_electroShopLocalService = electroShopLocalService;
	}

	/**
	 * Adds the electro shop to the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect ElectroShopLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param electroShop the electro shop
	 * @return the electro shop that was added
	 */
	@Override
	public ru.isands.test.estore.model.ElectroShop addElectroShop(
		ru.isands.test.estore.model.ElectroShop electroShop) {

		return _electroShopLocalService.addElectroShop(electroShop);
	}

	/**
	 * Creates a new electro shop with the primary key. Does not add the electro shop to the database.
	 *
	 * @param electroShopPK the primary key for the new electro shop
	 * @return the new electro shop
	 */
	@Override
	public ru.isands.test.estore.model.ElectroShop createElectroShop(
		ru.isands.test.estore.service.persistence.ElectroShopPK electroShopPK) {

		return _electroShopLocalService.createElectroShop(electroShopPK);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel createPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _electroShopLocalService.createPersistedModel(primaryKeyObj);
	}

	/**
	 * Deletes the electro shop from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect ElectroShopLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param electroShop the electro shop
	 * @return the electro shop that was removed
	 */
	@Override
	public ru.isands.test.estore.model.ElectroShop deleteElectroShop(
		ru.isands.test.estore.model.ElectroShop electroShop) {

		return _electroShopLocalService.deleteElectroShop(electroShop);
	}

	/**
	 * Deletes the electro shop with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect ElectroShopLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param electroShopPK the primary key of the electro shop
	 * @return the electro shop that was removed
	 * @throws PortalException if a electro shop with the primary key could not be found
	 */
	@Override
	public ru.isands.test.estore.model.ElectroShop deleteElectroShop(
			ru.isands.test.estore.service.persistence.ElectroShopPK
				electroShopPK)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _electroShopLocalService.deleteElectroShop(electroShopPK);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel deletePersistedModel(
			com.liferay.portal.kernel.model.PersistedModel persistedModel)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _electroShopLocalService.deletePersistedModel(persistedModel);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _electroShopLocalService.dynamicQuery();
	}

	/**
	 * Performs a dynamic query on the database and returns the matching rows.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _electroShopLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	 * Performs a dynamic query on the database and returns a range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ru.isands.test.estore.model.impl.ElectroShopModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @return the range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) {

		return _electroShopLocalService.dynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * Performs a dynamic query on the database and returns an ordered range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ru.isands.test.estore.model.impl.ElectroShopModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<T> orderByComparator) {

		return _electroShopLocalService.dynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _electroShopLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @param projection the projection to apply to the query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {

		return _electroShopLocalService.dynamicQueryCount(
			dynamicQuery, projection);
	}

	@Override
	public ru.isands.test.estore.model.ElectroShop fetchElectroShop(
		ru.isands.test.estore.service.persistence.ElectroShopPK electroShopPK) {

		return _electroShopLocalService.fetchElectroShop(electroShopPK);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery
		getActionableDynamicQuery() {

		return _electroShopLocalService.getActionableDynamicQuery();
	}

	/**
	 * Returns the electro shop with the primary key.
	 *
	 * @param electroShopPK the primary key of the electro shop
	 * @return the electro shop
	 * @throws PortalException if a electro shop with the primary key could not be found
	 */
	@Override
	public ru.isands.test.estore.model.ElectroShop getElectroShop(
			ru.isands.test.estore.service.persistence.ElectroShopPK
				electroShopPK)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _electroShopLocalService.getElectroShop(electroShopPK);
	}

	/**
	 * Returns a range of all the electro shops.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ru.isands.test.estore.model.impl.ElectroShopModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of electro shops
	 * @param end the upper bound of the range of electro shops (not inclusive)
	 * @return the range of electro shops
	 */
	@Override
	public java.util.List<ru.isands.test.estore.model.ElectroShop>
		getElectroShops(int start, int end) {

		return _electroShopLocalService.getElectroShops(start, end);
	}

	/**
	 * Returns the number of electro shops.
	 *
	 * @return the number of electro shops
	 */
	@Override
	public int getElectroShopsCount() {
		return _electroShopLocalService.getElectroShopsCount();
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.IndexableActionableDynamicQuery
		getIndexableActionableDynamicQuery() {

		return _electroShopLocalService.getIndexableActionableDynamicQuery();
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	@Override
	public String getOSGiServiceIdentifier() {
		return _electroShopLocalService.getOSGiServiceIdentifier();
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel getPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _electroShopLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	 * Updates the electro shop in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect ElectroShopLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param electroShop the electro shop
	 * @return the electro shop that was updated
	 */
	@Override
	public ru.isands.test.estore.model.ElectroShop updateElectroShop(
		ru.isands.test.estore.model.ElectroShop electroShop) {

		return _electroShopLocalService.updateElectroShop(electroShop);
	}

	@Override
	public ElectroShopLocalService getWrappedService() {
		return _electroShopLocalService;
	}

	@Override
	public void setWrappedService(
		ElectroShopLocalService electroShopLocalService) {

		_electroShopLocalService = electroShopLocalService;
	}

	private ElectroShopLocalService _electroShopLocalService;

}