/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package ru.isands.test.estore.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link ElectroShop}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ElectroShop
 * @generated
 */
public class ElectroShopWrapper
	extends BaseModelWrapper<ElectroShop>
	implements ElectroShop, ModelWrapper<ElectroShop> {

	public ElectroShopWrapper(ElectroShop electroShop) {
		super(electroShop);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("shopId", getShopId());
		attributes.put("electroItemId", getElectroItemId());
		attributes.put("count", getCount());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long shopId = (Long)attributes.get("shopId");

		if (shopId != null) {
			setShopId(shopId);
		}

		Long electroItemId = (Long)attributes.get("electroItemId");

		if (electroItemId != null) {
			setElectroItemId(electroItemId);
		}

		Integer count = (Integer)attributes.get("count");

		if (count != null) {
			setCount(count);
		}
	}

	/**
	 * Returns the count of this electro shop.
	 *
	 * @return the count of this electro shop
	 */
	@Override
	public int getCount() {
		return model.getCount();
	}

	/**
	 * Returns the electro item ID of this electro shop.
	 *
	 * @return the electro item ID of this electro shop
	 */
	@Override
	public long getElectroItemId() {
		return model.getElectroItemId();
	}

	/**
	 * Returns the primary key of this electro shop.
	 *
	 * @return the primary key of this electro shop
	 */
	@Override
	public ru.isands.test.estore.service.persistence.ElectroShopPK
		getPrimaryKey() {

		return model.getPrimaryKey();
	}

	/**
	 * Returns the shop ID of this electro shop.
	 *
	 * @return the shop ID of this electro shop
	 */
	@Override
	public long getShopId() {
		return model.getShopId();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the count of this electro shop.
	 *
	 * @param count the count of this electro shop
	 */
	@Override
	public void setCount(int count) {
		model.setCount(count);
	}

	/**
	 * Sets the electro item ID of this electro shop.
	 *
	 * @param electroItemId the electro item ID of this electro shop
	 */
	@Override
	public void setElectroItemId(long electroItemId) {
		model.setElectroItemId(electroItemId);
	}

	/**
	 * Sets the primary key of this electro shop.
	 *
	 * @param primaryKey the primary key of this electro shop
	 */
	@Override
	public void setPrimaryKey(
		ru.isands.test.estore.service.persistence.ElectroShopPK primaryKey) {

		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the shop ID of this electro shop.
	 *
	 * @param shopId the shop ID of this electro shop
	 */
	@Override
	public void setShopId(long shopId) {
		model.setShopId(shopId);
	}

	@Override
	protected ElectroShopWrapper wrap(ElectroShop electroShop) {
		return new ElectroShopWrapper(electroShop);
	}

}