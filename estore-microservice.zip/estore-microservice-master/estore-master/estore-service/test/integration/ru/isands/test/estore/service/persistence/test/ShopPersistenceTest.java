/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package ru.isands.test.estore.service.persistence.test;

import com.liferay.arquillian.extension.junit.bridge.junit.Arquillian;
import com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.ProjectionFactoryUtil;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.test.rule.AggregateTestRule;
import com.liferay.portal.kernel.test.util.RandomTestUtil;
import com.liferay.portal.kernel.transaction.Propagation;
import com.liferay.portal.kernel.util.IntegerWrapper;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.OrderByComparatorFactoryUtil;
import com.liferay.portal.test.rule.LiferayIntegrationTestRule;
import com.liferay.portal.test.rule.PersistenceTestRule;
import com.liferay.portal.test.rule.TransactionalTestRule;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import ru.isands.test.estore.exception.NoSuchShopException;
import ru.isands.test.estore.model.Shop;
import ru.isands.test.estore.service.ShopLocalServiceUtil;
import ru.isands.test.estore.service.persistence.ShopPersistence;
import ru.isands.test.estore.service.persistence.ShopUtil;

/**
 * @generated
 */
@RunWith(Arquillian.class)
public class ShopPersistenceTest {

	@ClassRule
	@Rule
	public static final AggregateTestRule aggregateTestRule =
		new AggregateTestRule(
			new LiferayIntegrationTestRule(), PersistenceTestRule.INSTANCE,
			new TransactionalTestRule(
				Propagation.REQUIRED, "ru.isands.test.estore.service"));

	@Before
	public void setUp() {
		_persistence = ShopUtil.getPersistence();

		Class<?> clazz = _persistence.getClass();

		_dynamicQueryClassLoader = clazz.getClassLoader();
	}

	@After
	public void tearDown() throws Exception {
		Iterator<Shop> iterator = _shops.iterator();

		while (iterator.hasNext()) {
			_persistence.remove(iterator.next());

			iterator.remove();
		}
	}

	@Test
	public void testCreate() throws Exception {
		long pk = RandomTestUtil.nextLong();

		Shop shop = _persistence.create(pk);

		Assert.assertNotNull(shop);

		Assert.assertEquals(shop.getPrimaryKey(), pk);
	}

	@Test
	public void testRemove() throws Exception {
		Shop newShop = addShop();

		_persistence.remove(newShop);

		Shop existingShop = _persistence.fetchByPrimaryKey(
			newShop.getPrimaryKey());

		Assert.assertNull(existingShop);
	}

	@Test
	public void testUpdateNew() throws Exception {
		addShop();
	}

	@Test
	public void testUpdateExisting() throws Exception {
		long pk = RandomTestUtil.nextLong();

		Shop newShop = _persistence.create(pk);

		newShop.setName(RandomTestUtil.randomString());

		newShop.setAddress(RandomTestUtil.randomString());

		_shops.add(_persistence.update(newShop));

		Shop existingShop = _persistence.findByPrimaryKey(
			newShop.getPrimaryKey());

		Assert.assertEquals(existingShop.getId(), newShop.getId());
		Assert.assertEquals(existingShop.getName(), newShop.getName());
		Assert.assertEquals(existingShop.getAddress(), newShop.getAddress());
	}

	@Test
	public void testFindByPrimaryKeyExisting() throws Exception {
		Shop newShop = addShop();

		Shop existingShop = _persistence.findByPrimaryKey(
			newShop.getPrimaryKey());

		Assert.assertEquals(existingShop, newShop);
	}

	@Test(expected = NoSuchShopException.class)
	public void testFindByPrimaryKeyMissing() throws Exception {
		long pk = RandomTestUtil.nextLong();

		_persistence.findByPrimaryKey(pk);
	}

	@Test
	public void testFindAll() throws Exception {
		_persistence.findAll(
			QueryUtil.ALL_POS, QueryUtil.ALL_POS, getOrderByComparator());
	}

	protected OrderByComparator<Shop> getOrderByComparator() {
		return OrderByComparatorFactoryUtil.create(
			"estore_Shop", "id", true, "name", true);
	}

	@Test
	public void testFetchByPrimaryKeyExisting() throws Exception {
		Shop newShop = addShop();

		Shop existingShop = _persistence.fetchByPrimaryKey(
			newShop.getPrimaryKey());

		Assert.assertEquals(existingShop, newShop);
	}

	@Test
	public void testFetchByPrimaryKeyMissing() throws Exception {
		long pk = RandomTestUtil.nextLong();

		Shop missingShop = _persistence.fetchByPrimaryKey(pk);

		Assert.assertNull(missingShop);
	}

	@Test
	public void testFetchByPrimaryKeysWithMultiplePrimaryKeysWhereAllPrimaryKeysExist()
		throws Exception {

		Shop newShop1 = addShop();
		Shop newShop2 = addShop();

		Set<Serializable> primaryKeys = new HashSet<Serializable>();

		primaryKeys.add(newShop1.getPrimaryKey());
		primaryKeys.add(newShop2.getPrimaryKey());

		Map<Serializable, Shop> shops = _persistence.fetchByPrimaryKeys(
			primaryKeys);

		Assert.assertEquals(2, shops.size());
		Assert.assertEquals(newShop1, shops.get(newShop1.getPrimaryKey()));
		Assert.assertEquals(newShop2, shops.get(newShop2.getPrimaryKey()));
	}

	@Test
	public void testFetchByPrimaryKeysWithMultiplePrimaryKeysWhereNoPrimaryKeysExist()
		throws Exception {

		long pk1 = RandomTestUtil.nextLong();

		long pk2 = RandomTestUtil.nextLong();

		Set<Serializable> primaryKeys = new HashSet<Serializable>();

		primaryKeys.add(pk1);
		primaryKeys.add(pk2);

		Map<Serializable, Shop> shops = _persistence.fetchByPrimaryKeys(
			primaryKeys);

		Assert.assertTrue(shops.isEmpty());
	}

	@Test
	public void testFetchByPrimaryKeysWithMultiplePrimaryKeysWhereSomePrimaryKeysExist()
		throws Exception {

		Shop newShop = addShop();

		long pk = RandomTestUtil.nextLong();

		Set<Serializable> primaryKeys = new HashSet<Serializable>();

		primaryKeys.add(newShop.getPrimaryKey());
		primaryKeys.add(pk);

		Map<Serializable, Shop> shops = _persistence.fetchByPrimaryKeys(
			primaryKeys);

		Assert.assertEquals(1, shops.size());
		Assert.assertEquals(newShop, shops.get(newShop.getPrimaryKey()));
	}

	@Test
	public void testFetchByPrimaryKeysWithNoPrimaryKeys() throws Exception {
		Set<Serializable> primaryKeys = new HashSet<Serializable>();

		Map<Serializable, Shop> shops = _persistence.fetchByPrimaryKeys(
			primaryKeys);

		Assert.assertTrue(shops.isEmpty());
	}

	@Test
	public void testFetchByPrimaryKeysWithOnePrimaryKey() throws Exception {
		Shop newShop = addShop();

		Set<Serializable> primaryKeys = new HashSet<Serializable>();

		primaryKeys.add(newShop.getPrimaryKey());

		Map<Serializable, Shop> shops = _persistence.fetchByPrimaryKeys(
			primaryKeys);

		Assert.assertEquals(1, shops.size());
		Assert.assertEquals(newShop, shops.get(newShop.getPrimaryKey()));
	}

	@Test
	public void testActionableDynamicQuery() throws Exception {
		final IntegerWrapper count = new IntegerWrapper();

		ActionableDynamicQuery actionableDynamicQuery =
			ShopLocalServiceUtil.getActionableDynamicQuery();

		actionableDynamicQuery.setPerformActionMethod(
			new ActionableDynamicQuery.PerformActionMethod<Shop>() {

				@Override
				public void performAction(Shop shop) {
					Assert.assertNotNull(shop);

					count.increment();
				}

			});

		actionableDynamicQuery.performActions();

		Assert.assertEquals(count.getValue(), _persistence.countAll());
	}

	@Test
	public void testDynamicQueryByPrimaryKeyExisting() throws Exception {
		Shop newShop = addShop();

		DynamicQuery dynamicQuery = DynamicQueryFactoryUtil.forClass(
			Shop.class, _dynamicQueryClassLoader);

		dynamicQuery.add(RestrictionsFactoryUtil.eq("id", newShop.getId()));

		List<Shop> result = _persistence.findWithDynamicQuery(dynamicQuery);

		Assert.assertEquals(1, result.size());

		Shop existingShop = result.get(0);

		Assert.assertEquals(existingShop, newShop);
	}

	@Test
	public void testDynamicQueryByPrimaryKeyMissing() throws Exception {
		DynamicQuery dynamicQuery = DynamicQueryFactoryUtil.forClass(
			Shop.class, _dynamicQueryClassLoader);

		dynamicQuery.add(
			RestrictionsFactoryUtil.eq("id", RandomTestUtil.nextLong()));

		List<Shop> result = _persistence.findWithDynamicQuery(dynamicQuery);

		Assert.assertEquals(0, result.size());
	}

	@Test
	public void testDynamicQueryByProjectionExisting() throws Exception {
		Shop newShop = addShop();

		DynamicQuery dynamicQuery = DynamicQueryFactoryUtil.forClass(
			Shop.class, _dynamicQueryClassLoader);

		dynamicQuery.setProjection(ProjectionFactoryUtil.property("id"));

		Object newId = newShop.getId();

		dynamicQuery.add(
			RestrictionsFactoryUtil.in("id", new Object[] {newId}));

		List<Object> result = _persistence.findWithDynamicQuery(dynamicQuery);

		Assert.assertEquals(1, result.size());

		Object existingId = result.get(0);

		Assert.assertEquals(existingId, newId);
	}

	@Test
	public void testDynamicQueryByProjectionMissing() throws Exception {
		DynamicQuery dynamicQuery = DynamicQueryFactoryUtil.forClass(
			Shop.class, _dynamicQueryClassLoader);

		dynamicQuery.setProjection(ProjectionFactoryUtil.property("id"));

		dynamicQuery.add(
			RestrictionsFactoryUtil.in(
				"id", new Object[] {RandomTestUtil.nextLong()}));

		List<Object> result = _persistence.findWithDynamicQuery(dynamicQuery);

		Assert.assertEquals(0, result.size());
	}

	protected Shop addShop() throws Exception {
		long pk = RandomTestUtil.nextLong();

		Shop shop = _persistence.create(pk);

		shop.setName(RandomTestUtil.randomString());

		shop.setAddress(RandomTestUtil.randomString());

		_shops.add(_persistence.update(shop));

		return shop;
	}

	private List<Shop> _shops = new ArrayList<Shop>();
	private ShopPersistence _persistence;
	private ClassLoader _dynamicQueryClassLoader;

}