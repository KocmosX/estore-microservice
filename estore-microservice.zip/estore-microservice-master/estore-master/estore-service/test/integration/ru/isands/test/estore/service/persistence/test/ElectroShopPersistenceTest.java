/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package ru.isands.test.estore.service.persistence.test;

import com.liferay.arquillian.extension.junit.bridge.junit.Arquillian;
import com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.ProjectionFactoryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.test.rule.AggregateTestRule;
import com.liferay.portal.kernel.test.util.RandomTestUtil;
import com.liferay.portal.kernel.transaction.Propagation;
import com.liferay.portal.kernel.util.IntegerWrapper;
import com.liferay.portal.test.rule.LiferayIntegrationTestRule;
import com.liferay.portal.test.rule.PersistenceTestRule;
import com.liferay.portal.test.rule.TransactionalTestRule;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import ru.isands.test.estore.exception.NoSuchElectroShopException;
import ru.isands.test.estore.model.ElectroShop;
import ru.isands.test.estore.service.ElectroShopLocalServiceUtil;
import ru.isands.test.estore.service.persistence.ElectroShopPK;
import ru.isands.test.estore.service.persistence.ElectroShopPersistence;
import ru.isands.test.estore.service.persistence.ElectroShopUtil;

/**
 * @generated
 */
@RunWith(Arquillian.class)
public class ElectroShopPersistenceTest {

	@ClassRule
	@Rule
	public static final AggregateTestRule aggregateTestRule =
		new AggregateTestRule(
			new LiferayIntegrationTestRule(), PersistenceTestRule.INSTANCE,
			new TransactionalTestRule(
				Propagation.REQUIRED, "ru.isands.test.estore.service"));

	@Before
	public void setUp() {
		_persistence = ElectroShopUtil.getPersistence();

		Class<?> clazz = _persistence.getClass();

		_dynamicQueryClassLoader = clazz.getClassLoader();
	}

	@After
	public void tearDown() throws Exception {
		Iterator<ElectroShop> iterator = _electroShops.iterator();

		while (iterator.hasNext()) {
			_persistence.remove(iterator.next());

			iterator.remove();
		}
	}

	@Test
	public void testCreate() throws Exception {
		ElectroShopPK pk = new ElectroShopPK(
			RandomTestUtil.nextLong(), RandomTestUtil.nextLong());

		ElectroShop electroShop = _persistence.create(pk);

		Assert.assertNotNull(electroShop);

		Assert.assertEquals(electroShop.getPrimaryKey(), pk);
	}

	@Test
	public void testRemove() throws Exception {
		ElectroShop newElectroShop = addElectroShop();

		_persistence.remove(newElectroShop);

		ElectroShop existingElectroShop = _persistence.fetchByPrimaryKey(
			newElectroShop.getPrimaryKey());

		Assert.assertNull(existingElectroShop);
	}

	@Test
	public void testUpdateNew() throws Exception {
		addElectroShop();
	}

	@Test
	public void testUpdateExisting() throws Exception {
		ElectroShopPK pk = new ElectroShopPK(
			RandomTestUtil.nextLong(), RandomTestUtil.nextLong());

		ElectroShop newElectroShop = _persistence.create(pk);

		newElectroShop.setCount(RandomTestUtil.nextInt());

		_electroShops.add(_persistence.update(newElectroShop));

		ElectroShop existingElectroShop = _persistence.findByPrimaryKey(
			newElectroShop.getPrimaryKey());

		Assert.assertEquals(
			existingElectroShop.getShopId(), newElectroShop.getShopId());
		Assert.assertEquals(
			existingElectroShop.getElectroItemId(),
			newElectroShop.getElectroItemId());
		Assert.assertEquals(
			existingElectroShop.getCount(), newElectroShop.getCount());
	}

	@Test
	public void testFindByPrimaryKeyExisting() throws Exception {
		ElectroShop newElectroShop = addElectroShop();

		ElectroShop existingElectroShop = _persistence.findByPrimaryKey(
			newElectroShop.getPrimaryKey());

		Assert.assertEquals(existingElectroShop, newElectroShop);
	}

	@Test(expected = NoSuchElectroShopException.class)
	public void testFindByPrimaryKeyMissing() throws Exception {
		ElectroShopPK pk = new ElectroShopPK(
			RandomTestUtil.nextLong(), RandomTestUtil.nextLong());

		_persistence.findByPrimaryKey(pk);
	}

	@Test
	public void testFetchByPrimaryKeyExisting() throws Exception {
		ElectroShop newElectroShop = addElectroShop();

		ElectroShop existingElectroShop = _persistence.fetchByPrimaryKey(
			newElectroShop.getPrimaryKey());

		Assert.assertEquals(existingElectroShop, newElectroShop);
	}

	@Test
	public void testFetchByPrimaryKeyMissing() throws Exception {
		ElectroShopPK pk = new ElectroShopPK(
			RandomTestUtil.nextLong(), RandomTestUtil.nextLong());

		ElectroShop missingElectroShop = _persistence.fetchByPrimaryKey(pk);

		Assert.assertNull(missingElectroShop);
	}

	@Test
	public void testFetchByPrimaryKeysWithMultiplePrimaryKeysWhereAllPrimaryKeysExist()
		throws Exception {

		ElectroShop newElectroShop1 = addElectroShop();
		ElectroShop newElectroShop2 = addElectroShop();

		Set<Serializable> primaryKeys = new HashSet<Serializable>();

		primaryKeys.add(newElectroShop1.getPrimaryKey());
		primaryKeys.add(newElectroShop2.getPrimaryKey());

		Map<Serializable, ElectroShop> electroShops =
			_persistence.fetchByPrimaryKeys(primaryKeys);

		Assert.assertEquals(2, electroShops.size());
		Assert.assertEquals(
			newElectroShop1, electroShops.get(newElectroShop1.getPrimaryKey()));
		Assert.assertEquals(
			newElectroShop2, electroShops.get(newElectroShop2.getPrimaryKey()));
	}

	@Test
	public void testFetchByPrimaryKeysWithMultiplePrimaryKeysWhereNoPrimaryKeysExist()
		throws Exception {

		ElectroShopPK pk1 = new ElectroShopPK(
			RandomTestUtil.nextLong(), RandomTestUtil.nextLong());

		ElectroShopPK pk2 = new ElectroShopPK(
			RandomTestUtil.nextLong(), RandomTestUtil.nextLong());

		Set<Serializable> primaryKeys = new HashSet<Serializable>();

		primaryKeys.add(pk1);
		primaryKeys.add(pk2);

		Map<Serializable, ElectroShop> electroShops =
			_persistence.fetchByPrimaryKeys(primaryKeys);

		Assert.assertTrue(electroShops.isEmpty());
	}

	@Test
	public void testFetchByPrimaryKeysWithMultiplePrimaryKeysWhereSomePrimaryKeysExist()
		throws Exception {

		ElectroShop newElectroShop = addElectroShop();

		ElectroShopPK pk = new ElectroShopPK(
			RandomTestUtil.nextLong(), RandomTestUtil.nextLong());

		Set<Serializable> primaryKeys = new HashSet<Serializable>();

		primaryKeys.add(newElectroShop.getPrimaryKey());
		primaryKeys.add(pk);

		Map<Serializable, ElectroShop> electroShops =
			_persistence.fetchByPrimaryKeys(primaryKeys);

		Assert.assertEquals(1, electroShops.size());
		Assert.assertEquals(
			newElectroShop, electroShops.get(newElectroShop.getPrimaryKey()));
	}

	@Test
	public void testFetchByPrimaryKeysWithNoPrimaryKeys() throws Exception {
		Set<Serializable> primaryKeys = new HashSet<Serializable>();

		Map<Serializable, ElectroShop> electroShops =
			_persistence.fetchByPrimaryKeys(primaryKeys);

		Assert.assertTrue(electroShops.isEmpty());
	}

	@Test
	public void testFetchByPrimaryKeysWithOnePrimaryKey() throws Exception {
		ElectroShop newElectroShop = addElectroShop();

		Set<Serializable> primaryKeys = new HashSet<Serializable>();

		primaryKeys.add(newElectroShop.getPrimaryKey());

		Map<Serializable, ElectroShop> electroShops =
			_persistence.fetchByPrimaryKeys(primaryKeys);

		Assert.assertEquals(1, electroShops.size());
		Assert.assertEquals(
			newElectroShop, electroShops.get(newElectroShop.getPrimaryKey()));
	}

	@Test
	public void testActionableDynamicQuery() throws Exception {
		final IntegerWrapper count = new IntegerWrapper();

		ActionableDynamicQuery actionableDynamicQuery =
			ElectroShopLocalServiceUtil.getActionableDynamicQuery();

		actionableDynamicQuery.setPerformActionMethod(
			new ActionableDynamicQuery.PerformActionMethod<ElectroShop>() {

				@Override
				public void performAction(ElectroShop electroShop) {
					Assert.assertNotNull(electroShop);

					count.increment();
				}

			});

		actionableDynamicQuery.performActions();

		Assert.assertEquals(count.getValue(), _persistence.countAll());
	}

	@Test
	public void testDynamicQueryByPrimaryKeyExisting() throws Exception {
		ElectroShop newElectroShop = addElectroShop();

		DynamicQuery dynamicQuery = DynamicQueryFactoryUtil.forClass(
			ElectroShop.class, _dynamicQueryClassLoader);

		dynamicQuery.add(
			RestrictionsFactoryUtil.eq(
				"id.shopId", newElectroShop.getShopId()));
		dynamicQuery.add(
			RestrictionsFactoryUtil.eq(
				"id.electroItemId", newElectroShop.getElectroItemId()));

		List<ElectroShop> result = _persistence.findWithDynamicQuery(
			dynamicQuery);

		Assert.assertEquals(1, result.size());

		ElectroShop existingElectroShop = result.get(0);

		Assert.assertEquals(existingElectroShop, newElectroShop);
	}

	@Test
	public void testDynamicQueryByPrimaryKeyMissing() throws Exception {
		DynamicQuery dynamicQuery = DynamicQueryFactoryUtil.forClass(
			ElectroShop.class, _dynamicQueryClassLoader);

		dynamicQuery.add(
			RestrictionsFactoryUtil.eq("id.shopId", RandomTestUtil.nextLong()));
		dynamicQuery.add(
			RestrictionsFactoryUtil.eq(
				"id.electroItemId", RandomTestUtil.nextLong()));

		List<ElectroShop> result = _persistence.findWithDynamicQuery(
			dynamicQuery);

		Assert.assertEquals(0, result.size());
	}

	@Test
	public void testDynamicQueryByProjectionExisting() throws Exception {
		ElectroShop newElectroShop = addElectroShop();

		DynamicQuery dynamicQuery = DynamicQueryFactoryUtil.forClass(
			ElectroShop.class, _dynamicQueryClassLoader);

		dynamicQuery.setProjection(ProjectionFactoryUtil.property("id.shopId"));

		Object newShopId = newElectroShop.getShopId();

		dynamicQuery.add(
			RestrictionsFactoryUtil.in("id.shopId", new Object[] {newShopId}));

		List<Object> result = _persistence.findWithDynamicQuery(dynamicQuery);

		Assert.assertEquals(1, result.size());

		Object existingShopId = result.get(0);

		Assert.assertEquals(existingShopId, newShopId);
	}

	@Test
	public void testDynamicQueryByProjectionMissing() throws Exception {
		DynamicQuery dynamicQuery = DynamicQueryFactoryUtil.forClass(
			ElectroShop.class, _dynamicQueryClassLoader);

		dynamicQuery.setProjection(ProjectionFactoryUtil.property("id.shopId"));

		dynamicQuery.add(
			RestrictionsFactoryUtil.in(
				"id.shopId", new Object[] {RandomTestUtil.nextLong()}));

		List<Object> result = _persistence.findWithDynamicQuery(dynamicQuery);

		Assert.assertEquals(0, result.size());
	}

	protected ElectroShop addElectroShop() throws Exception {
		ElectroShopPK pk = new ElectroShopPK(
			RandomTestUtil.nextLong(), RandomTestUtil.nextLong());

		ElectroShop electroShop = _persistence.create(pk);

		electroShop.setCount(RandomTestUtil.nextInt());

		_electroShops.add(_persistence.update(electroShop));

		return electroShop;
	}

	private List<ElectroShop> _electroShops = new ArrayList<ElectroShop>();
	private ElectroShopPersistence _persistence;
	private ClassLoader _dynamicQueryClassLoader;

}