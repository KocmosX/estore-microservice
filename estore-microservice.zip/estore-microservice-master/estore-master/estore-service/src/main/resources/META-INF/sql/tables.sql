create table estore_ElectroShop (
	shopId LONG not null,
	electroItemId LONG not null,
	count INTEGER,
	primary key (shopId, electroItemId)
);

create table estore_Employee (
	id_ LONG not null primary key,
	lastName VARCHAR(100) null,
	firstName VARCHAR(100) null,
	patronymic VARCHAR(100) null,
	birthDate DATE null,
	positionId LONG,
	shopId LONG,
	gender BOOLEAN
);

create table estore_PositionType (
	id_ LONG not null primary key,
	name VARCHAR(75) null
);

create table estore_Purchase (
	id_ LONG not null primary key,
	electroId LONG,
	employeeId LONG,
	shopId LONG,
	purchaseDate DATE null,
	type_ INTEGER
);

create table estore_Shop (
	id_ LONG not null primary key,
	name VARCHAR(150) null,
	address TEXT null
);