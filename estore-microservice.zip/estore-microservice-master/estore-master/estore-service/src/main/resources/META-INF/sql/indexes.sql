create unique index IX_293A13AE on estore_Employee (lastName[$COLUMN_LENGTH:100$], firstName[$COLUMN_LENGTH:100$], patronymic[$COLUMN_LENGTH:100$], birthDate);
create index IX_1CA1AAAF on estore_Employee (positionId);
create index IX_9D1E527C on estore_Employee (shopId);

create index IX_DA72BEC7 on estore_Purchase (employeeId);
create index IX_117CE50F on estore_Purchase (shopId);