/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package ru.isands.test.estore.model.impl;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import ru.isands.test.estore.model.ElectroShop;
import ru.isands.test.estore.service.persistence.ElectroShopPK;

/**
 * The cache model class for representing ElectroShop in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class ElectroShopCacheModel
	implements CacheModel<ElectroShop>, Externalizable {

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof ElectroShopCacheModel)) {
			return false;
		}

		ElectroShopCacheModel electroShopCacheModel =
			(ElectroShopCacheModel)object;

		if (electroShopPK.equals(electroShopCacheModel.electroShopPK)) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, electroShopPK);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(7);

		sb.append("{shopId=");
		sb.append(shopId);
		sb.append(", electroItemId=");
		sb.append(electroItemId);
		sb.append(", count=");
		sb.append(count);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public ElectroShop toEntityModel() {
		ElectroShopImpl electroShopImpl = new ElectroShopImpl();

		electroShopImpl.setShopId(shopId);
		electroShopImpl.setElectroItemId(electroItemId);
		electroShopImpl.setCount(count);

		electroShopImpl.resetOriginalValues();

		return electroShopImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		shopId = objectInput.readLong();

		electroItemId = objectInput.readLong();

		count = objectInput.readInt();

		electroShopPK = new ElectroShopPK(shopId, electroItemId);
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		objectOutput.writeLong(shopId);

		objectOutput.writeLong(electroItemId);

		objectOutput.writeInt(count);
	}

	public long shopId;
	public long electroItemId;
	public int count;
	public transient ElectroShopPK electroShopPK;

}