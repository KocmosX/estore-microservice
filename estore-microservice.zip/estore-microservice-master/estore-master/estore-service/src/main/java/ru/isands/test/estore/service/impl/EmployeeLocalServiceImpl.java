/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package ru.isands.test.estore.service.impl;

import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.util.OrderByComparator;

import java.util.Date;
import java.util.List;

import org.osgi.service.component.annotations.Component;

import ru.isands.test.estore.model.Employee;
import ru.isands.test.estore.service.base.EmployeeLocalServiceBaseImpl;

/**
 * @author Brian Wing Shun Chan
 */
@Component(
	property = "model.class.name=ru.isands.test.estore.model.Employee",
	service = AopService.class
)
public class EmployeeLocalServiceImpl extends EmployeeLocalServiceBaseImpl {
	
	/**
	 * Поиск сотрудника по ФИО и дате рождения
	 * @param lastName - фамилия
	 * @param firstName - имя
	 * @param patronymic - отчество
	 * @param birthDate - дата рождения
	 * @return запись сотрудника, либо null
	 */
	public Employee findByFullName(String lastName, String firstName, String patronymic, Date birthDate) {
		return employeePersistence.fetchByFullName(lastName, firstName, patronymic, birthDate);
	}
	
	/**
	 * Поиск сотрудников по идентификатору должности
	 * @param positionId - идентификатор должности
	 * @return список, либо null
	 */
	public List<Employee> findByPosition(long positionId) {
		return employeePersistence.findByPosition(positionId);
	}
	
	/**
	 * Поиск первого добавленного сотрудника по идентификатору должности
	 * @param positionId - идентификатор должности
	 * @return запись сотрудника, либо null
	 */
	public Employee findFirstPosition(long positionId) {
		return employeePersistence.fetchByPosition_First(positionId, new OrderByComparator<Employee>() {			
			private static final long serialVersionUID = 1L;

			@Override
			public int compare(Employee o1, Employee o2) {
				return o1.getId()>o2.getId() ? -1 : 1;
			}
		});
	}
}