/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package ru.isands.test.estore.model.impl;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import ru.isands.test.estore.model.Shop;

/**
 * The cache model class for representing Shop in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class ShopCacheModel implements CacheModel<Shop>, Externalizable {

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof ShopCacheModel)) {
			return false;
		}

		ShopCacheModel shopCacheModel = (ShopCacheModel)object;

		if (id == shopCacheModel.id) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, id);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(7);

		sb.append("{id=");
		sb.append(id);
		sb.append(", name=");
		sb.append(name);
		sb.append(", address=");
		sb.append(address);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public Shop toEntityModel() {
		ShopImpl shopImpl = new ShopImpl();

		shopImpl.setId(id);

		if (name == null) {
			shopImpl.setName("");
		}
		else {
			shopImpl.setName(name);
		}

		if (address == null) {
			shopImpl.setAddress("");
		}
		else {
			shopImpl.setAddress(address);
		}

		shopImpl.resetOriginalValues();

		return shopImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput)
		throws ClassNotFoundException, IOException {

		id = objectInput.readLong();
		name = objectInput.readUTF();
		address = (String)objectInput.readObject();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		objectOutput.writeLong(id);

		if (name == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(name);
		}

		if (address == null) {
			objectOutput.writeObject("");
		}
		else {
			objectOutput.writeObject(address);
		}
	}

	public long id;
	public String name;
	public String address;

}