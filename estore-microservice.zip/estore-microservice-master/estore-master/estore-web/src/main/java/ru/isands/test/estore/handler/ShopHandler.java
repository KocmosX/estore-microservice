package ru.isands.test.estore.handler;

import com.liferay.counter.kernel.service.CounterLocalService;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;

import javax.portlet.*;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import ru.isands.test.estore.model.Shop;
import ru.isands.test.estore.service.ShopLocalService;

/**
 * @author isands
 */
@Component(
	property = { "handler.type=tShop"}, service = Handler.class
)
public class ShopHandler extends Handler {
	
	@Reference
	ShopLocalService shopService;
	
	@Reference
	CounterLocalService counterService;
	
	@Override
	public void read(PortletRequest portletRequest) {
		final ThemeDisplay themeDisplay = (ThemeDisplay) portletRequest.getAttribute(WebKeys.THEME_DISPLAY);
		final String sessionId = portletRequest.getRequestedSessionId();
		if (themeDisplay == null) {
			addError("Внутренняя ошибка с порталом. Попробуйте отправить запрос позднее", sessionId, themeDisplay);
			return;
		}
		final long id = ParamUtil.getLong(portletRequest, "id");
		Shop shop = id>0 ? shopService.fetchShop(id) : shopService.createShop(0);
		shop.setName(ParamUtil.getString(portletRequest, "name").trim());
		shop.setAddress(ParamUtil.getString(portletRequest, "address").trim());
		portletRequest.setAttribute("item", shop);
	}

	@Override
	public void validate(PortletRequest portletRequest, PortletResponse portletResponse) {
		final Shop item = (Shop) portletRequest.getAttribute("item");
		final ThemeDisplay themeDisplay = (ThemeDisplay) portletRequest.getAttribute(WebKeys.THEME_DISPLAY);
		final String sessionId = portletRequest.getRequestedSessionId();
		if (themeDisplay == null || item == null) {
			addError("Внутренняя ошибка с порталом. Попробуйте отправить запрос позднее", sessionId, themeDisplay);
			return;
		}
		if (Validator.isBlank(item.getName()))
			addError("shop.name.error.null", sessionId, themeDisplay);
		if (Validator.isBlank(item.getAddress()))
			addError("shop.address.error.null", sessionId, themeDisplay);
		DynamicQuery query = shopService.dynamicQuery();
		query.add(RestrictionsFactoryUtil.eq("name", item.getName()));
		query.add(RestrictionsFactoryUtil.ne("id", item.getId()));
		if (shopService.dynamicQueryCount(query)>0)
			addError("shop.name.exists", sessionId, themeDisplay);
		query = shopService.dynamicQuery();
		query.add(RestrictionsFactoryUtil.eq("address", item.getAddress()));
		query.add(RestrictionsFactoryUtil.ne("id", item.getId()));
		if (shopService.dynamicQueryCount(query)>0)
			addError("shop.address.exists", sessionId, themeDisplay);
	}
	
	@Override
	public void save(PortletRequest portletRequest, PortletResponse portletResponse) {
		final Shop item = (Shop) portletRequest.getAttribute("item");
		// новая запись - создаем новый id
		if (item.getId()<=0)
			item.setId(counterService.increment(Shop.class.getName()));
		shopService.updateShop(item);
	}

	@Override
	public String getIdValue(ActionRequest actionRequest) {
		final Shop item = (Shop) actionRequest.getAttribute("item");
		return String.valueOf(item.getId());
	}
	
}