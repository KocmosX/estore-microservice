package ru.isands.test.estore.constants;

/**
 * @author isands
 */
public class EStoreKeys {

	public static final String REGISTR_PORTLET = "ru_isands_estore_RegistrPortlet";
	public static final String DICT_PORTLET = "ru_isands_estore_DictPortlet";

}