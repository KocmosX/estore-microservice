package ru.isands.test.estore.item;

import com.liferay.portal.kernel.util.DateUtil;

import java.io.Serializable;
import java.util.Locale;

import ru.isands.test.estore.model.Employee;
import ru.isands.test.estore.model.PositionType;
import ru.isands.test.estore.model.Shop;
import ru.isands.test.estore.service.PositionTypeLocalService;
import ru.isands.test.estore.service.ShopLocalService;

public class EmployeeItem implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	long id;
	String lastName;
	String firstName;
	String patronymic;
	String birthDate;
	String shop;
	String position;
	
	public EmployeeItem(Employee emp, ShopLocalService shopService, PositionTypeLocalService positionTypeService, Locale locale) {
		super();
		this.id = emp.getId();
		this.lastName = emp.getLastName();
		this.firstName = emp.getFirstName();
		this.patronymic = emp.getPatronymic();
		if (emp.getBirthDate()!=null)
			this.birthDate = DateUtil.getDate(emp.getBirthDate(), "dd-MM-yyyy", locale);
		final Shop shopItem = shopService.fetchShop(emp.getShopId());
		this.shop = shopItem == null ? "Неизвестно" : shopItem.getName();
		final PositionType positionType = positionTypeService.fetchPositionType(emp.getPositionId());
		this.position = positionType == null ? "Не указано" : positionType.getName();
	}

	public long getId() {
		return id;
	}

	public String getLastName() {
		return lastName;
	}
	
	public String getFirstName() {
		return firstName;
	}

	public String getPatronymic() {
		return patronymic;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public String getShop() {
		return shop;
	}

	public String getPosition() {
		return position;
	}
	
}