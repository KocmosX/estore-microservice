package ru.isands.test.estore.handler;

import com.liferay.counter.kernel.service.CounterLocalService;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.DateUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;

import java.text.ParseException;

import javax.portlet.*;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import ru.isands.test.estore.model.Employee;
import ru.isands.test.estore.service.EmployeeLocalService;

/**
 * @author isands
 */
@Component(
	property = { "handler.type=tEmp"}, service = Handler.class
)
public class EmployeeHandler extends Handler {
	
	@Reference
	EmployeeLocalService employeeService;
	
	@Reference
	CounterLocalService counterService;
	
	@Override
	public void read(PortletRequest portletRequest) {
		final ThemeDisplay themeDisplay = (ThemeDisplay) portletRequest.getAttribute(WebKeys.THEME_DISPLAY);
		final String sessionId = portletRequest.getRequestedSessionId();
		if (themeDisplay == null) {
			addError("Внутренняя ошибка с порталом. Попробуйте отправить запрос позднее", sessionId, themeDisplay);
			return;
		}
		final long id = ParamUtil.getLong(portletRequest, "id");
		Employee employee = id>0 ? employeeService.fetchEmployee(id) : employeeService.createEmployee(0);
		employee.setLastName(ParamUtil.getString(portletRequest, "lastName"));
		employee.setFirstName(ParamUtil.getString(portletRequest, "firstName"));
		employee.setPatronymic(ParamUtil.getString(portletRequest, "patronymic"));
		final String birthDate = ParamUtil.getString(portletRequest, "birthDate");
		if (!Validator.isBlank(birthDate))
			try {
				employee.setBirthDate(DateUtil.parseDate("dd-MM-yyyy", birthDate, themeDisplay.getLocale()));
			} catch (ParseException e) {
				addError("employee.birthdate.error.parse", sessionId, themeDisplay);
				return;
			}
		employee.setGender("genderMale".equals(ParamUtil.getString(portletRequest, "gender")));
		employee.setPositionId(ParamUtil.getLong(portletRequest, "positionId"));
		employee.setShopId(ParamUtil.getLong(portletRequest, "shopId"));
		portletRequest.setAttribute("item", employee);
	}

	@Override
	public void validate(PortletRequest portletRequest, PortletResponse portletResponse) {
		final Employee item = (Employee) portletRequest.getAttribute("item");
		final ThemeDisplay themeDisplay = (ThemeDisplay) portletRequest.getAttribute(WebKeys.THEME_DISPLAY);
		final String sessionId = portletRequest.getRequestedSessionId();
		if (themeDisplay == null || item == null) {
			addError("Внутренняя ошибка с порталом. Попробуйте отправить запрос позднее", sessionId, themeDisplay);
			return;
		}
		if (Validator.isBlank(item.getLastName()))
			addError("employee.lastname.error.null", sessionId, themeDisplay);
		if (Validator.isBlank(item.getFirstName()))
			addError("employee.firstname.error.null", sessionId, themeDisplay);
		if (Validator.isBlank(item.getPatronymic()))
			addError("employee.patronymic.error.null", sessionId, themeDisplay);
		if (item.getBirthDate()==null)
			addError("employee.birthdate.error.null", sessionId, themeDisplay);
		if (item.getShopId()<=0)
			addError("employee.shop.error.null", sessionId, themeDisplay);
		final Employee existEmployee = employeeService.findByFullName(item.getLastName(), item.getFirstName(), item.getPatronymic(), item.getBirthDate());
		if (existEmployee !=null && existEmployee.getId() != item.getId())
			addError("employee.item.exists", sessionId, themeDisplay);
	}
	
	@Override
	public void save(PortletRequest portletRequest, PortletResponse portletResponse) {
		final Employee item = (Employee) portletRequest.getAttribute("item");
		// новая запись - создаем новый id
		if (item.getId()<=0)
			item.setId(counterService.increment(Employee.class.getName()));
		employeeService.updateEmployee(item);
	}

	@Override
	public String getIdValue(ActionRequest actionRequest) {
		final Employee item = (Employee) actionRequest.getAttribute("item");
		return String.valueOf(item.getId());
	}
	
}