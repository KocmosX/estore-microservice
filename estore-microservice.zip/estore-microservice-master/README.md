**EStore-microservice**

Шаблон микросервиса запускается в среде выполнения **JVM 11**

Собран для крайней версии spring-boot **2.7.18**, добавлен springdoc-ui для автогенерации документации по разработанным rest-методам

**Доступ к swagger-ui:** http://localhost:8081/estore-api.html